const updatePasswordComponent = () => {
    return <div className="container">
    <div className="row">
   
    </div>
    </div>
}