export interface RegisterInterface {
    username: string
    email: string
    password: string
  }
